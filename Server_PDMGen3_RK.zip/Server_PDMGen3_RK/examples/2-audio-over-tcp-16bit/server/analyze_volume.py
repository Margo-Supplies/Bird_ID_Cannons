import sys
import librosa
import numpy as np

wav_file = sys.argv[1]

y, sr = librosa.load(wav_file, sr=16000)
rms = librosa.feature.rms(y=y)[0]
db = librosa.amplitude_to_db(rms, ref=np.max)
avg_db = db.mean()

print(avg_db)
