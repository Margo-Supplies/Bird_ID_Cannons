import sys
import librosa
import librosa.display
import matplotlib.pyplot as plt
import numpy as np
import os
import soundfile as sf
import noisereduce as nr
from scipy.signal import butter, filtfilt

# Function to apply a Butterworth bandpass filter
def butter_bandpass(lowcut, highcut, fs, order=4):
    nyquist = 0.5 * fs
    low = lowcut / nyquist
    high = highcut / nyquist
    b, a = butter(order, [low, high], btype='band')
    return b, a

def butter_bandpass_filter(data, lowcut, highcut, fs, order=4):
    b, a = butter_bandpass(lowcut, highcut, fs, order=order)
    y = filtfilt(b, a, data)
    return y

# Load WAV file and output PNG file paths
wav_file = sys.argv[1]
output_png = sys.argv[2]

# Load the audio data
y, sr = librosa.load(wav_file, sr=16000)

y_reduced_noise = nr.reduce_noise(y=y, sr=sr)

# Apply Butterworth bandpass filter
lowcut = 150.0  # Low cutoff frequency in Hz
highcut = 1500.0  # High cutoff frequency in Hz
y_filtered = butter_bandpass_filter(y_reduced_noise, lowcut, highcut, sr)

# Compute the mel spectrogram on the filtered signal
S = librosa.feature.melspectrogram(y=y_filtered, sr=sr, n_fft=1024, hop_length=1024, n_mels=128, fmin=0, window='hann')
S_dB = librosa.power_to_db(S, ref=np.max)

# Adjusted threshold for determining silence
max_dB = np.max(S_dB)

# Set a threshold, for example, -10 dB
threshold_dB = -15

if max_dB < threshold_dB:
    print(f"File {wav_file} is mostly silent ({max_dB} dB), deleting.")
    os.remove(wav_file)
    if os.path.exists(output_png):
        os.remove(output_png)
else:
    plt.figure(figsize=(10, 4))
    plt.axis('off')
    librosa.display.specshow(S_dB, sr=sr, hop_length=1024, x_axis=None, y_axis=None)

    plt.tight_layout(pad=0)
    plt.savefig(output_png, bbox_inches='tight', pad_inches=0)
    plt.close()
    print(f"Mel spectrogram saved to {output_png}")
