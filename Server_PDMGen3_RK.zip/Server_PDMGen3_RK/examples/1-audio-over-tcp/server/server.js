// Install
// npm install
// 
// Run
// npm run

var fs = require('fs');
var path = require('path');
var net = require('net');
var os = require('os');
var wav = require('wav');

var outputDir = path.join(__dirname, "out");  
var dataPort = 7123;
var wavOpts = {
    'channels':1,
    'sampleRate':16000,
    'bitDepth':16
};

var lastNum = 0;

try {
    fs.mkdirSync(outputDir);
}
catch(e) {}

function getLocalIpAddress() {
    var interfaces = os.networkInterfaces();
    for (var ifaceName in interfaces) {
        var iface = interfaces[ifaceName];
        for (var i = 0; i < iface.length; i++) {
            var alias = iface[i];
            if (alias.family === 'IPv4' && !alias.internal) {
                return alias.address;
            }
        }
    }
    return '127.0.0.1'; // fallback to localhost if no IP is found
}

net.createServer(function (socket) {
    console.log('Data connection started from ' + socket.remoteAddress);
    
    socket.setEncoding('hex');
    
    var outPath = getUniqueOutputPath();
    var writer = new wav.FileWriter(outPath, wavOpts);
    
    socket.on('data', function (data) {
        var buf = new Buffer(data, 'hex');
        writer.write(buf);
    });

    socket.on('end', function () {
        console.log('Transmission complete, saved to ' + outPath);
        writer.end();
    });
}).listen(dataPort, function() {
    console.log('Server started on port ' + dataPort);
    console.log('Server IP address: ' + getLocalIpAddress());
});

function formatName(num) {
    var s = num.toString();
    while(s.length < 5) {
        s = '0' + s;
    }
    return s + '.wav';
}

function getUniqueOutputPath() {
    for(var ii = lastNum + 1; ii < 99999; ii++) {
        var outPath = path.join(outputDir, formatName(ii));
        try {
            fs.statSync(outPath);
        }
        catch(e) {
            lastNum = ii;
            return outPath;
        }
    }
    lastNum = 0;
    return "00000.wav";
}
