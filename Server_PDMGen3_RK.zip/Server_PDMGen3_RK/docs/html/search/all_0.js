var searchData=
[
  ['availablesamples',['availableSamples',['../class_p_d_m_gen3.html#a4d2af06a2c24308d5dde3e1f8756287e',1,'PDMGen3']]]
];
