var searchData=
[
  ['getavailablesamples',['getAvailableSamples',['../class_p_d_m_gen3.html#a05ab9761c189dc165720a3812f9e1751',1,'PDMGen3']]],
  ['getsamplesperbuf',['getSamplesPerBuf',['../class_p_d_m_gen3.html#af03d8865f6414498ae6213675098a10f',1,'PDMGen3']]]
];
