var searchData=
[
  ['gainl',['gainL',['../class_p_d_m_gen3.html#a8f5641dca0d5886ad147a5f12c143189',1,'PDMGen3']]],
  ['gainr',['gainR',['../class_p_d_m_gen3.html#ad9c7302b9e9f1ff06669e8e8bf1b081e',1,'PDMGen3']]]
];
