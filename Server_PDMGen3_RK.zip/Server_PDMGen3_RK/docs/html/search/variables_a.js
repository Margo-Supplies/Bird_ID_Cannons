var searchData=
[
  ['samples',['samples',['../class_p_d_m_gen3.html#a64bbe854ae34d281cb342ae58cd7f4bc',1,'PDMGen3']]],
  ['samplesperbuf',['samplesPerBuf',['../class_p_d_m_gen3.html#aac94f05c2cb217b03abd3af9a5e72aab',1,'PDMGen3']]],
  ['staticbuffer',['staticBuffer',['../class_p_d_m_gen3_static.html#afd4ec7cc9155f9b67f48fab720225a9f',1,'PDMGen3Static']]]
];
